create view vSchedulePatients as
	select s.ID, s.Status, s.Note as ScheduleNote, s.EventBegin, s.EventEnd, s.StaffID, s.WorkplaceID, w.Building, w.Floor, w.Room, w.Note as WorkplaceNote, s.PatientID, p.HumanID, p.FirstName, p.LastName, p.Birthday, p.Sex
	from Schedules s
	left join Workplaces w on w.ID = s.WorkplaceID
	left join vPatients p on p.RoleID = s.PatientID
GO
