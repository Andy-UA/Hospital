create view vStaff 
as
	select r.ID as RoleID, r.Category, r.Enabled as RoleEnabled, r.Note as RoleNote, h.FirstName, h.LastName, h.Birthday, h.Enabled as HumanEnabled, h.Sex, h.ID as HumanID, h.Note as HumanNote
	from Roles r
	inner join Humans h on h.ID = r.HumanID
	where r.Scope = 2 --scope = 2 is staff
GO
