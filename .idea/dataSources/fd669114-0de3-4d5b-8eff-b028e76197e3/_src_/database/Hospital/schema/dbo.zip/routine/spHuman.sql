CREATE procedure [dbo].[spHuman](@login nvarchar(50), @password nvarchar(50))
as 
begin
	select * from Humans h where exists(select * from Accounts a where a.HumanID = h.ID and a.Enabled = 1 and a.Login = @login and a.Password = @password)
end
GO
