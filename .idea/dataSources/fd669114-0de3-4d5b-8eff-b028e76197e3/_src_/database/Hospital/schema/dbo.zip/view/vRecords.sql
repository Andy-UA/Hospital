create view vRecords as
	select r.ID, r.Note as RecordNote, r.EventDate, r.ScheduleID, s.StaffID, s.PatientID, r.DiagnosisID, d.Code as DiagnosisCode, d.Name as DiagnosisName, d.Note as DiagnosisNote
	from Records r
	left join Diagnosis d on d.ID = r.DiagnosisID
	left join Schedules s on s.ID = r.ScheduleID
GO
