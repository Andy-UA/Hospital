create view vRecordDetails as
	select d.ID, d.RecordID, d.AppointmentID, a.Description as AppointmentDescription, a.Unit as AppointmentUnit, a.Type as AppointmentType, a.Note as AppointmentNote, d.Status, d.Amount, d.Note as DetailNote 
	from RecordDetails d
	left join Appointments a on a.ID = d.AppointmentID
GO
